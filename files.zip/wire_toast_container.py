with open('client/src/App.jsx') as f:
    content = f.read()

old_import = 'import { useGlobalClickSound } from "./utils/useGlobalClickSound";'
new_import = 'import { useGlobalClickSound } from "./utils/useGlobalClickSound";\nimport ToastContainer from "./components/ToastContainer";'

assert content.count(old_import) == 1, "import anchor not found"
content = content.replace(old_import, new_import)

old_return = "useGlobalClickSound();\n\n  return ("
new_return = "useGlobalClickSound();\n\n  return (\n    <>\n      <ToastContainer />"

assert content.count(old_return) == 1, "return anchor not found"
content = content.replace(old_return, new_return)

with open('client/src/App.jsx', 'w') as f:
    f.write(content)

print("ToastContainer wired in (part 1).")
