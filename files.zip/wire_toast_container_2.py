with open('client/src/App.jsx') as f:
    content = f.read()

old_end = '</Routes>\n  );\n}\n\nexport default App;'
new_end = '</Routes>\n    </>\n  );\n}\n\nexport default App;'

count = content.count(old_end)
assert count == 1, f"expected 1 match, found {count}"
content = content.replace(old_end, new_end)

with open('client/src/App.jsx', 'w') as f:
    f.write(content)

print("Fragment closed (part 2).")
