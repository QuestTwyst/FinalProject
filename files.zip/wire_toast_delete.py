with open('client/src/components/StoryLibrary.jsx') as f:
    content = f.read()

# 1. Add the import
old_import = "import EditStoryModal from './EditStoryModal';"
new_import = "import EditStoryModal from './EditStoryModal';\nimport { showToast } from '../utils/toast';"

assert content.count(old_import) == 1, "import anchor not found"
content = content.replace(old_import, new_import)

# 2. Replace the handler body
old_handler = """const handleDeleteStory = async (storyId) => {
    try {
      const authToken = localStorage.getItem('authToken');

      const response = await fetch(`${API_BASE_URL}/stories/${storyId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${authToken}`,
      },
      });
      if (!response.ok) {
        throw new Error(`Failed to delete story (${response.status})`);
      }
      setStories((prev) => prev.filter((story) => story.id !== storyId));
    } catch (error) {
      console.error('Error deleting story:', error);
      window.alert('Something went wrong deleting that story. Please try again.');
    }
  };"""

new_handler = """const handleDeleteStory = async (storyId) => {
    try {
      const authToken = localStorage.getItem('authToken');

      const response = await fetch(`${API_BASE_URL}/stories/${storyId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${authToken}`,
      },
      });
      if (!response.ok) {
        throw new Error(`Failed to delete story (${response.status})`);
      }
      setStories((prev) => prev.filter((story) => story.id !== storyId));
      showToast('Story deleted.', 'success');
    } catch (error) {
      console.error('Error deleting story:', error);
      showToast('Something went wrong deleting that story. Please try again.', 'error');
    }
  };"""

count = content.count(old_handler)
assert count == 1, f"handler anchor: expected 1, found {count}"
content = content.replace(old_handler, new_handler)

with open('client/src/components/StoryLibrary.jsx', 'w') as f:
    f.write(content)

print("Toast wired into delete handler.")
